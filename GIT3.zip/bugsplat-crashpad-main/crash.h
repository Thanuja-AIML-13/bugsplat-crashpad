#ifndef CRASH_LIB_H
#define CRASH_LIB_H

#ifdef __cplusplus
extern "C" {
#endif

void crash(void);

#ifdef __cplusplus
}
#endif

#endif // CRASH_LIB_H 